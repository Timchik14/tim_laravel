<?php

namespace App\Models;

class Article extends Model
{
//    use HasFactory;

    public function scopePublished($query)
    {
        return $query->where('published', 1);
    }

    public function getRouteKeyName()
    {
        return 'slug';
    }
}
