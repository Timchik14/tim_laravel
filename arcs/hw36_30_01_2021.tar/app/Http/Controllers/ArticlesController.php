<?php

namespace App\Http\Controllers;

use App\Models\Article;

class ArticlesController extends Controller
{
    public function index()
    {
        $articles = Article::latest()->published()->get();
        return view('index', compact('articles'));
    }

    public function about()
    {
        $articles = Article::latest()->published()->get();
        return view('about.index');
    }


    public function show(Article $article)
    {
        return view('posts.show', compact('article'));
    }

    public function create()
    {
        return view('posts.create');
    }

    public function store()
    {
        $this->validate(request(), [
            'slug' => 'required|unique:articles|regex:/^[a-zA-Z0-9-_]+$/',
            'name' => 'required|min:5|max:100',
            'short_description' => 'required|max:255',
            'long_description' => 'required',
            'body' => 'required',
        ]);
        $all = request()->all();
        $all['published'] = (request()->get('published') === 'on');
        Article::create($all);
        return redirect('/');
    }
}
