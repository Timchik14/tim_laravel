<?php

use App\Http\Controllers\ArticlesController;

Route::get('/', [ArticlesController::class, 'index']);

Route::get('/about', [ArticlesController::class, 'about']);

Route::get('/posts/create', [ArticlesController::class, 'create']);

Route::post('/posts', [ArticlesController::class, 'store']);

Route::get('/posts/{article}', [ArticlesController::class, 'show']);

use App\Http\Controllers\FeedbackController;

Route::get('/contacts', [FeedbackController::class, 'create']);

Route::post('/contacts', [FeedbackController::class, 'store']);

Route::get('/admin/feedbacks', [FeedbackController::class, 'show']);

