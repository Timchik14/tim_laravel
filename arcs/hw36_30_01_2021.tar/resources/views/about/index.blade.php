@extends('layout.master')

@section('content')
    <div class="col-md-8 blog-main">
        <h3 class="pb-3 mb-4 font-italic border-bottom">
            About
        </h3>
        <div class="blog-post">
            <h2 class="blog-post-title">Информация о нас</h2>
            <hr>
            <p class="blog-post-meta">Какой то текст</p>
            <hr>
        </div>

    </div>

@endsection
