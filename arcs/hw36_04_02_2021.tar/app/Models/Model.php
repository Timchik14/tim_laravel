<?php


namespace App\Models;


class Model extends \Illuminate\Database\Eloquent\Model
{
    public $guarded = [];
}
