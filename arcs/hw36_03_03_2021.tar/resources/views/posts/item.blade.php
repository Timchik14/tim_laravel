<div class="blog-post">
    <a href="posts/{{ $post->slug }}"><h2 class="blog-post-title">{{ $post->name }}</h2><a>
    <p class="blog-post-meta">{{ $post->created_at->toFormattedDateString() }}</p>
    <hr>
    <p>{{ $post->short_description }}</p>
    <hr>
</div>
